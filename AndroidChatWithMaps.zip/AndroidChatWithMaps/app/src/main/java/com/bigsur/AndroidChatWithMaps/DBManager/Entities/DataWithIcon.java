package com.bigsur.AndroidChatWithMaps.DBManager.Entities;



public interface DataWithIcon {

//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public void setSubname(String subname) {
//        this.subname = subname;
//    }
//
//    public void setAvatar(int avatar) {
//        this.avatar = avatar;
//    }
//
//    public void setDate(int date) {
//        this.date = date;
//    }
//
//    private int id;
//    private String name;
//    private String subname;
//    private int avatar;
//    private int date;

    public int getId();

    public String getName();

    public String getSubname();

    public int getAvatar();

    public int getDate();


   /* public DataWithIcon(String name, String subname) {
        this.name = name;
        this.subname = subname;
    }*/
}
